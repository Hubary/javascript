var CONTEXT = '/api/'

module.exports = function(path) {
    return CONTEXT + path
}